/**
 * End-to-end check of the full Square flow, run against whichever modes are configured.
 *   npm test
 * With no credentials this exercises demo mode; with sandbox keys in .env it hits PayPal for real.
 */
import { negotiate, decide, captureExpense } from "../lib/agents";
import { createPaymentToken, createSetupToken, paypalMode } from "../lib/paypal";
import { getDB, mutate, resetDB } from "../lib/store";
import { verifyMessage } from "../lib/trust";
import type { UserId } from "../lib/types";


function assert(cond: unknown, what: string) {
  if (!cond) {
    console.error(`FAIL: ${what}`);
    process.exit(1);
  }
  console.log(`ok  ${what}`);
}

async function link(user: UserId) {
  const t = await createSetupToken({ human: user, returnUrl: "http://localhost/r", cancelUrl: "http://localhost/c" });
  const p = await createPaymentToken(t.id, getDB().users[user].sandboxEmail);
  mutate((d) => {
    d.users[user].paypal = { status: "linked", paymentTokenId: p.id, payerId: p.payerId, payerEmail: p.email, mode: "demo" };
  });
}

async function main() {
  if (paypalMode() !== "demo") {
    console.log("Live PayPal credentials found; this script only runs the demo-mode flow. Unset them to run it.");
    return;
  }
  resetDB(false);

  // Invoice path: Alex owes but has no agent allowance yet.
  const inv = await negotiate();
  assert(inv.status === "invoiced", "unlinked debtor gets an itemized PayPal invoice instead of a charge");
  assert(inv.agreedAmount === 241, `wine dispute accepted, fado dispute declined (agreed ${inv.agreedAmount})`);

  resetDB(false);
  await link("alex");
  await link("maya");

  const n = await negotiate();
  const types = n.messages.map((m) => m.type).join(" > ");
  console.log(`    ${types}`);
  assert(n.initialTotal === 253, `opening statement is $253 (got ${n.initialTotal})`);
  assert(n.disputes.length === 2, "Alex's agent disputes two lines");
  assert(n.disputes.find((d) => d.itemLabel.includes("vinho"))?.accepted === true, "Maya's agent accepts the wine dispute");
  assert(n.disputes.find((d) => d.itemLabel.includes("tickets"))?.accepted === false, "Maya's agent declines the ticket dispute");
  assert(n.status === "awaiting_approval", "$241 exceeds Alex's $150 auto-approve limit, so it escalates");
  assert(n.messages.every(verifyMessage), "every agent message carries a valid signature");

  const s = await decide(n.id, "approved");
  assert(s.status === "settled", "after approval the payment settles");
  assert(s.settlement?.orderId && s.settlement.payoutBatchId, "order and payout ids recorded");
  assert(s.messages.some((m) => m.type === "CONFIRM" && m.data?.verified), "creditor's agent verified the order on PayPal");
  assert(getDB().expenses.every((e) => e.settledIn), "ledger closed");
  const wine = getDB().expenses.flatMap((e) => e.items).find((i) => i.id === "i_wine")!;
  assert(!wine.sharedBy.includes("alex"), "wine adjustment made permanent");

  const again = await negotiate();
  assert(again.status === "nothing_owed", "nothing owed after settling");

  const added = await captureExpense("maya", "I paid $30 for tapas");
  assert(added.expense.items[0].amount === 30, "chat message becomes a ledger entry");
  const small = await negotiate();
  assert(small.status === "settled" && small.agreedAmount === 15, "$15 is under the limit, so the agents settle without asking");

  console.log("\nAll checks passed.");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
