"""Assemble the demo video: one encoded file per scene (captions burnt in), concat, then add the voiceover."""
import json, os, subprocess

V = os.path.dirname(os.path.abspath(__file__))
OUT = f"{V}/out"
os.makedirs(OUT, exist_ok=True)
LEAD, TAIL = 0.5, 0.7
SCRIPT = json.load(open(f"{V}/script.json"))
CAP = json.load(open(f"{V}/capture.json"))
ENC = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p", "-r", "30"]


def run(cmd):
    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)


def ts(t):
    h, rem = divmod(t, 3600)
    m, s = divmod(rem, 60)
    return f"{int(h)}:{int(m):02d}:{s:05.2f}"


def write_ass(scene, dur, path):
    lines = scene["cap"]
    total = sum(len(l) for l in lines)
    t = LEAD
    events = []
    for l in lines:
        span = scene["dur"] * len(l) / total
        end = min(t + span + (TAIL if l is lines[-1] else 0.15), dur)
        events.append(f"Dialogue: 0,{ts(t)},{ts(end)},Cap,,0,0,0,,{l}")
        t += span
    open(path, "w").write(
        "[Script Info]\nScriptType: v4.00+\nPlayResX: 1920\nPlayResY: 1080\nWrapStyle: 0\n\n"
        "[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, "
        "Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
        "Style: Cap,Inter Medium,42,&H00FFFFFF,&H00FFFFFF,&H263D2114,&H263D2114,0,0,0,0,100,100,0,0,3,16,0,2,160,160,46,1\n\n"
        "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n" + "\n".join(events) + "\n"
    )


def scene_still(img, scene, dur, out, fade_in=False, fade_out=False):
    ass = f"{OUT}/{scene['id']}.ass"
    write_ass(scene, dur, ass)
    vf = f"format=yuv420p,loop=-1:1,trim=duration={dur}"
    if fade_in:
        vf += ",fade=t=in:st=0:d=0.8"
    if fade_out:
        vf += f",fade=t=out:st={dur - 1.2}:d=1.2"
    vf += f",subtitles={ass}"
    tmp = out.replace(".mp4", ".tmp.mp4")
    run(["ffmpeg", "-y", "-framerate", "30", "-i", img, "-vf", vf, *ENC, "-t", str(dur), tmp])
    os.replace(tmp, out)


def scene_film(scene, dur, out):
    start = CAP["marks"][scene["id"]]
    frames = CAP["frames"]
    chosen = [f for f in frames if start <= f[0] < start + dur]
    before = [f for f in frames if f[0] < start]
    if before:
        chosen = [(start, before[-1][1])] + chosen
    lst = f"{OUT}/{scene['id']}.txt"
    with open(lst, "w") as fh:
        for i, (t, path) in enumerate(chosen):
            nxt = chosen[i + 1][0] if i + 1 < len(chosen) else start + dur
            fh.write(f"file '{path}'\nduration {max(nxt - t, 0.001):.4f}\n")
        fh.write(f"file '{chosen[-1][1]}'\n")
    ass = f"{OUT}/{scene['id']}.ass"
    write_ass(scene, dur, ass)
    tmp = out.replace(".mp4", ".tmp.mp4")
    run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-vf", f"fps=30,format=yuv420p,subtitles={ass}", *ENC, "-t", str(dur), tmp])
    os.replace(tmp, out)


parts, audio_parts = [], []
for s in SCRIPT:
    dur = round(LEAD + s["dur"] + TAIL, 2)
    out = f"{OUT}/{s['id']}.mp4"
    if s["id"] == "s01_problem":
        dur = round(dur + 0.6, 2)
        scene_still(f"{V}/cards/problem.jpg", s, dur, out, fade_in=True)
    elif s["id"] == "s12_close":
        dur = round(dur + 1.6, 2)
        scene_still(f"{V}/cards/close.jpg", s, dur, out, fade_out=True)
    else:
        scene_film(s, dur, out)
    parts.append(out)
    a = f"{OUT}/{s['id']}.a.wav"
    lead_ms = int((LEAD + (0.6 if s["id"] == "s01_problem" else 0)) * 1000)
    run(["ffmpeg", "-y", "-i", f"{V}/audio/{s['id']}.wav", "-af", f"aresample=48000,adelay={lead_ms}:all=1,apad,atrim=0:{dur}", "-ac", "2", a])
    audio_parts.append(a)
    print(s["id"], dur)

open(f"{OUT}/video.txt", "w").write("".join(f"file '{p}'\n" for p in parts))
open(f"{OUT}/audio.txt", "w").write("".join(f"file '{p}'\n" for p in audio_parts))
run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", f"{OUT}/video.txt", "-c", "copy", f"{OUT}/silent.mp4"])
run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", f"{OUT}/audio.txt", "-af", "loudnorm=I=-16:TP=-1.5:LRA=11", "-ar", "48000", f"{OUT}/voice.wav"])
final = f"{V}/square-demo.mp4"
tmp = final.replace(".mp4", ".tmp.mp4")
run(["ffmpeg", "-y", "-i", f"{OUT}/silent.mp4", "-i", f"{OUT}/voice.wav", "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", tmp])
os.replace(tmp, final)
print("done", final)
