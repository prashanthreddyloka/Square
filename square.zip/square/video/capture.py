"""Film the Square app scene by scene: JPEG screenshots with timestamps while scripted actions run."""
import asyncio, json, os, sys, time, urllib.request
from playwright.async_api import async_playwright

V = os.path.dirname(os.path.abspath(__file__))
BASE = os.environ.get("APP", "http://localhost:3100")
LEAD, TAIL = 0.5, 0.7  # silence before / after each line of narration
SCRIPT = json.load(open(f"{V}/script.json"))
DUR = {s["id"]: round(LEAD + s["dur"] + TAIL, 2) for s in SCRIPT}
ONLY = sys.argv[1:]  # optional: scene ids to preview as stills only


def post(path, body=None):
    req = urllib.request.Request(BASE + path, data=json.dumps(body or {}).encode(), headers={"content-type": "application/json"}, method="POST")
    return json.loads(urllib.request.urlopen(req).read() or b"{}")


def prepare():
    post("/api/reset", {"keepPayPal": False})
    url = post("/api/paypal/connect", {"user": "alex"})["approveUrl"]
    urllib.request.urlopen(url.replace("http://localhost:3000", BASE)).read()


async def main():
    prepare()
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path="/usr/bin/google-chrome")
        pg = await b.new_page(viewport={"width": 1440, "height": 810}, device_scale_factor=4 / 3)
        await pg.goto(f"{BASE}/?present=1", wait_until="networkidle")
        await pg.wait_for_timeout(800)
        alex = pg.get_by_role("region", name="Alex's phone")
        maya = pg.get_by_role("region", name="Maya's phone")
        right = lambda: pg.keyboard.press("ArrowRight")
        settle = lambda: pg.get_by_role("button", name="Let our agents settle up").click()

        async def type_maya():
            box = maya.get_by_label("Message your agent")
            await box.click()
            await box.press_sequentially("I paid $30 for tapas", delay=45)
            await box.press("Enter")

        # (offset seconds, action) per scene
        plan = {
            "s02_meet": [(4.5, lambda: maya.get_by_role("tab", name="Shared expenses").click())],
            "s03_rules": [(0.4, lambda: alex.get_by_role("tab", name="Rules").click())],
            "s04_handshake": [
                (0.0, lambda: alex.get_by_role("tab", name="Agent").click()),
                (0.1, lambda: maya.get_by_role("tab", name="Agent").click()),
                (0.6, settle),
                (2.6, right), (5.0, right), (7.2, right),
            ],
            "s05_statement": [(0.5, right)],
            "s06_dispute": [(0.5, right)],
            "s07_ruling": [(0.5, right)],
            "s08_agree": [(0.5, right), (6.6, right)],
            "s09_pay": [(1.4, lambda: pg.get_by_role("button", name="Approve and pay").click()), (3.0, right), (5.0, right)],
            "s10_verify": [(0.6, right)],
            "s11_small": [(0.2, type_maya), (3.2, settle)] + [(4.2 + 0.55 * i, right) for i in range(7)],
        }

        frames = []  # (t, path)
        marks = {}
        stop = asyncio.Event()

        async def shooter():
            os.makedirs(f"{V}/frames", exist_ok=True)
            i = 0
            while not stop.is_set():
                t = time.monotonic()
                path = f"{V}/frames/f{i:05d}.jpg"
                await pg.screenshot(path=path, type="jpeg", quality=92)
                frames.append((t, path))
                i += 1

        if ONLY:
            for sid in [s["id"] for s in SCRIPT if s["id"] in plan]:
                for off, act in plan[sid]:
                    await act()
                    await pg.wait_for_timeout(700 if act is not right else 450)
                if sid in ONLY:
                    await pg.wait_for_timeout(900)
                    await pg.screenshot(path=f"{V}/preview_{sid}.jpg", type="jpeg", quality=92)
            await b.close()
            return

        task = asyncio.create_task(shooter())
        for s in SCRIPT:
            sid = s["id"]
            if sid not in plan:
                continue
            start = time.monotonic()
            marks[sid] = start
            for off, act in plan[sid]:
                wait = start + off - time.monotonic()
                if wait > 0:
                    await asyncio.sleep(wait)
                await act()
            rest = start + DUR[sid] - time.monotonic()
            if rest > 0:
                await asyncio.sleep(rest)
        stop.set()
        await task
        await b.close()
        json.dump({"frames": frames, "marks": marks, "dur": DUR}, open(f"{V}/capture.json", "w"))
        span = frames[-1][0] - frames[0][0]
        print(f"{len(frames)} frames over {span:.1f}s ({len(frames) / span:.1f} fps)")


asyncio.run(main())
