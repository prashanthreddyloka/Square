# Demo video pipeline

Re-records the demo video from the running app, so you can regenerate it in live mode (real PayPal sandbox + Claude).

Needs: ffmpeg with libass, Python Playwright, Google Chrome, RHVoice (`apt install rhvoice rhvoice-english`) and the Inter font for captions.

1. `npm run build && PORT=3100 npm start` (with your `.env` for live mode)
2. Synthesize the voiceover from `script.json` with RHVoice (voice `clb`), one WAV per scene in `video/audio/`, and store each duration as `dur` in `script.json`
3. Render the two title cards (`cards/*.html`) to `cards/problem.jpg` and `cards/close.jpg` at 1920x1080 (they expect a `cards/base.css` with the fonts)
4. `python3 video/capture.py` films each scene from `http://localhost:3100/?present=1`
5. `python3 video/build.py` encodes the scenes with burnt-in captions and adds the voice

In live mode, connect Alex's PayPal for real before step 4 and remove the scripted demo connect in `capture.py`'s `prepare()`.
