# Devpost submission kit

## Tagline

Your agent settles up with your friends' agents, on PayPal.

## Inspiration

Every group trip ends the same way: a spreadsheet, a pile of receipts, and someone sending the awkward "hey, you still owe me" text. Meanwhile, personal AI agents are arriving fast, and PayPal is already letting them shop at merchants. PayPal's CEO said on the Q3 2026 earnings call that agentic commerce will extend to peer-to-peer transfers, and that PayPal's job is to verify that both sides are real. Nobody has built that yet. So we did.

## What it does

Each person has an agent. You tell yours what you paid for, by text or with a receipt photo. When it's time to settle, the two agents talk to each other:

1. **Handshake.** Each presents a signed trust card bound to its human's PayPal-verified identity and current rules.
2. **Statement.** The creditor's agent sends an itemized bill computed by Square.
3. **Dispute.** The debtor's agent checks each line against what it knows ("Alex doesn't drink") and disputes what's unfair.
4. **Ruling.** The creditor's agent decides each dispute under its own human's rules ("drop what he didn't have, keep shared bookings").
5. **Agreement.** Square recomputes the number. The model never does the math.
6. **Guardrails.** If the amount is over the human's auto-approve limit or weekly cap, the agent asks first: one tap.
7. **Settlement.** Square charges the debtor's vaulted PayPal allowance and pays the friend with PayPal Payouts.
8. **Verification.** The receiving agent checks the order on PayPal itself, through the PayPal Agent Toolkit, before marking it settled. A signed receipt links the ledger, the agreement and the PayPal order.

If a friend hasn't connected PayPal, their agent can still negotiate, and the other agent sends an itemized PayPal invoice instead.

## How we built it

Next.js and TypeScript. Claude powers the agents: receipt reading with vision, line-by-line review and rulings with per-human personas, and a tool-use loop over PayPal Agent Toolkit tools for verification. PayPal Vault v3 setup and payment tokens give each agent a revocable allowance and a verified payer identity; Orders v2 with `vault_id` charges it; Payouts delivers to the friend; Invoicing (via the Agent Toolkit) covers friends without an agent; webhooks feed the activity log. Messages, trust cards and receipts are HMAC-signed.

## Challenges

Keeping the agents useful without letting them touch the money logic. We separated what the model decides (which lines are fair) from what code decides (the amount, and whether it can be sent). Making agent-to-agent trust visible was the other one: the receipt tape shows every signed message so a human can audit how the agents got to the number.

## What we're proud of

The receiving agent doesn't trust the paying agent; it checks PayPal itself. And every settlement leaves an evidence trail, which is the answer to "what does a dispute look like when no human pressed pay?"

## What's next

Groups larger than two, recurring splits for roommates, settling into Venmo, and plugging Square's protocol into personal agents like Meta's Muse so your existing assistant can settle up for you.

## Tools used

- **Claude (Anthropic API)**: expense extraction from text and receipt photos, agent negotiation, tool-use verification.
- **PayPal Agent Toolkit**: `get_order`, `create_invoice`, `send_invoice`, exposed to Claude as tools.
- **PayPal REST APIs (sandbox)**: Vault v3, Orders v2, Payouts v1, Invoicing v2, Webhooks.
- **Render**: hosting.

---

# Demo video script (target 2:40)

Judges score Technological Implementation, Design, Potential Impact, Innovation and Presentation from 1 to 5, and they aren't required to run the project, so the video has to prove all five on its own. Every scene below is tagged with what it proves.

Before recording: run in live mode (real PayPal sandbox + Claude), connect Alex's PayPal allowance off camera, press **Reset the trip**, and open a second browser tab on the PayPal sandbox site logged in as Maya. Don't show setup, loading or typing delays; cut them.

| Time | On screen | Voiceover | Proves |
|---|---|---|---|
| 0:00 | Black title card: "Who owes who after a trip?" then a messy group-chat screenshot of IOU texts (make your own, no real app logos) | "Every shared trip ends with receipts, spreadsheets and someone sending the awkward 'you still owe me' text. Square is for friends, roommates and travel groups who'd rather their AI agents handled it." | Impact |
| 0:15 | Square, two phones, ledger tab | "Alex and Maya just got back from Lisbon. Maya paid for most of it. Each of them has a personal agent that kept track, from chat messages and receipt photos." | Idea |
| 0:25 | Cut to Rules tab: allowance approved, $150 limit, $500 weekly cap | "Alex approved one PayPal allowance for his agent, with his own rules: up to $150 without asking, never more than $500 a week." | Tech (Vault) |
| 0:35 | Click "Let our agents settle up"; handshake + trust check print | "Now the agents settle it, not the people. First they prove who they work for: signed trust cards, bound to PayPal-verified accounts." | Innovation |
| 0:50 | Statement prints | "Maya's agent sends an itemized bill: $253." | Design |
| 0:58 | Dispute prints (zoom on it) | "Alex's agent, running on Claude, knows he doesn't drink and left the fado show early. It disputes both lines." | AI |
| 1:12 | Ruling prints | "Maya's agent follows Maya's rules: the wine comes off; the tickets were booked for both, so they stay." | AI |
| 1:25 | Agreement, needs approval, approval card on Alex's phone; tap Approve | "They agree on $241. The number is recomputed in code, never by the model. It's above Alex's limit, so his agent asks him. One tap." | Trust / Design |
| 1:40 | Payment sent with PayPal IDs; Maya's agent "payment verified" | "PayPal charges Alex's allowance and pays Maya with Payouts. Then Maya's agent checks the order on PayPal itself, through the PayPal Agent Toolkit, before it believes anything." | Tech (Orders, Payouts, Agent Toolkit) |
| 1:58 | Switch tab: Maya's PayPal sandbox balance showing the $241 | "And there it is in Maya's PayPal." | Working end to end |
| 2:05 | Back to Square: signed receipt at the bottom of the tape | "Every settle-up leaves a signed receipt: the evidence trail a dispute team needs when no human pressed pay." | Innovation |
| 2:13 | Maya sends a receipt photo; agent itemizes it; settle again, finishes with no prompt | "Small things? Snap the receipt, and under the limit the agents just handle it." | AI (vision) |
| 2:28 | Wide shot of both phones, "All square" | "PayPal is making shopping with agents trustworthy. Square brings that trust to money between friends." | Presentation |

Production notes:
- An AI voiceover is fine. Add captions; many judges watch muted.
- Record at 1440x900 in a clean browser window (no bookmarks bar, no other tabs visible).
- Use royalty-free music or none. Don't show third-party logos other than PayPal's own sandbox site.
- Upload to YouTube as **Public** at least a day early; processing can take hours.

---

# Timeline

PayPal offers an early eligibility check for anything submitted by **Thursday, Nov 5**. Aim for that, then keep improving: Devpost lets you edit until the deadline.

| By | Do |
|---|---|
| Tue Nov 3 | Sandbox app with Vault + Payouts enabled; PayPal and Anthropic keys in `.env`; run the full walkthrough live and send any errors to Claude |
| Wed Nov 4 | Public GitHub repo with MIT license in About; deploy to Render with `APP_URL` set; test Connect PayPal on the hosted URL; add the URL to the README |
| Thu Nov 5 | Record a first cut of the video, upload as Public, submit on Devpost (early eligibility check) |
| Nov 6 to 10 | Polish from feedback; re-record the video if needed and update the link |
| Wed Nov 11 | Final check: hosted demo works after a reset, video is public, repo is public |
| Thu Nov 12, 3:00pm ET | Deadline. Don't leave the final submit for the last hour |

Stage One eligibility checklist (what reviewers check first):
- [ ] Working build: hosted URL that works, and setup steps in the README
- [ ] Public repo with an open-source license visible in About
- [ ] Public YouTube video, under 3 minutes
- [ ] Meaningful PayPal use (Vault, Orders, Payouts, Agent Toolkit, Invoicing) and AI use (Claude) explained in the description
