# Square

**Personal AI agents that settle up between friends, on PayPal.**

You and your friends each have an agent. Your agent keeps track of what you pay for. When it's time to settle, your agent and your friend's agent talk to each other: they prove to each other that they act for real PayPal users, check every line of the bill against what they know about their humans, dispute what's unfair, agree on a number, and move the money through PayPal. You only get asked when one of your own rules says so.

Nobody has to send the "hey, you still owe me for the Airbnb" text again.

> PayPal's CEO said on the Q3 2026 earnings call that agentic commerce will extend beyond shopping to peer-to-peer transfers, and that PayPal's role is to be the layer that verifies both sides are real. Square is a working prototype of exactly that: agent-to-agent P2P with PayPal as the trust and settlement layer.

---

## Try it

**Hosted demo:** _add your Render URL here_

**Run locally (2 minutes, no keys needed):**

```bash
git clone <this repo> && cd square
npm install
npm run dev        # open http://localhost:3000
```

With no credentials, Square runs in **demo mode**: the full flow works and PayPal and Claude responses are simulated. The header shows which mode each side is in. Add keys (below) to run against the real PayPal sandbox and Claude.

### The 60-second walkthrough

1. On **Alex's phone**, open **Rules** and tap **Connect PayPal**. Approve the one-time agent allowance in PayPal (sandbox login).
2. Tap **Let our agents settle up** in the middle column.
3. Watch the agents' conversation print on the receipt tape:
   - **Handshake:** each agent presents a signed trust card bound to its human's PayPal identity and rules.
   - **Statement:** Maya's agent sends an itemized bill: Alex owes $253.
   - **Dispute:** Alex's agent knows Alex doesn't drink and left the fado show early, so it disputes the wine and the tickets.
   - **Ruling:** Maya's agent follows Maya's rules: drop things he didn't have (wine), keep shared bookings (tickets).
   - **Agreement:** $241, recomputed by Square, never by the model.
   - **Needs approval:** $241 is above Alex's $150 auto-approve limit, so his agent asks him.
4. Tap **Approve and pay** on Alex's phone. Square charges Alex's vaulted PayPal allowance, pays Maya with PayPal Payouts, and **Maya's agent independently checks the order on PayPal** (via the PayPal Agent Toolkit) before calling it settled. A signed receipt prints at the end.
5. Tell Maya's agent "I paid $30 for tapas" and settle again: $15 is under Alex's limit, so the agents finish without asking anyone.
6. Reset, skip step 1, and settle: Alex has no allowance, so Maya's agent sends him an itemized **PayPal invoice** instead.

Presenting live or recording? Open `/?present=1`: the tape then advances one message per press of the → key.

Tip: edit either person's rules or memory in the **Rules** tab and watch the agents negotiate differently.

---

## How it uses PayPal

| PayPal capability | Where Square uses it |
|---|---|
| **Vault v3: setup tokens + payment tokens** (save without purchase) | Each human approves an "agent allowance" once. The resulting payment token is what lets their agent pay later without them present. The token also gives us the PayPal-verified payer ID that goes on the agent's trust card. |
| **Orders v2 with `vault_id`** | The debtor's agent charges its human's allowance for exactly the agreed amount. |
| **Payouts v1** | Square forwards the money to the friend's PayPal account. |
| **PayPal Agent Toolkit** (`@paypal/agent-toolkit`) | Exposed to Claude as tools. The creditor's agent calls `get_order` itself to verify the payment instead of trusting the other agent. When the friend has no allowance, the agent uses `create_invoice` and `send_invoice` to send an itemized PayPal invoice. |
| **Invoicing v2** (through the toolkit) | Fallback settlement path, itemized line by line with the agreed adjustments. |
| **Webhooks** (`/api/webhooks/paypal`, signature-verified) | Capture, payout and invoice events show up in the activity log. |

All in the free PayPal **sandbox**.

## How it uses AI

Agents are powered by **Claude** (Anthropic Messages API, `claude-sonnet-5-5` by default):

- **Expense capture:** "Maya paid $40 for the museum" or a **receipt photo** (Claude vision) becomes itemized ledger lines, each tagged as consumable or a shared booking, so lines can be disputed individually.
- **Negotiation:** each agent gets a persona built from its own human's instructions and memory. The debtor's agent reviews the statement line by line and raises disputes with reasons. The creditor's agent rules on each one under its human's rules. Both write their own messages.
- **Verification with tools:** the creditor's agent runs a tool-use loop over PayPal Agent Toolkit tools to confirm the order on PayPal before signing off.

**What the model is not allowed to do:** compute money or decide whether money moves. Amounts are recomputed deterministically from the ledger and the accepted disputes (`lib/ledger.ts`). Spending limits and weekly caps are enforced in code (`lib/agents.ts`), not in the prompt. A prompt-injected agent can argue, but it can't overspend.

Without an `ANTHROPIC_API_KEY`, the same protocol runs on built-in rules so the demo always works.

## Trust, by design

- **Trust cards:** before any money moves, each agent presents a card binding it to a PayPal-verified human (payer ID from the vault token), whether it can pay, and a hash of its human's current rules. Cards are signed by Square and checked by the other side.
- **Signed messages:** every message on the tape is HMAC-signed with the sending agent's own key (`lib/trust.ts`).
- **Human in the loop where it matters:** per-settlement auto-approve limit and a weekly cap, set by each human.
- **Verify, don't trust:** the receiving agent checks PayPal itself.
- **Receipts:** each settlement produces a signed receipt linking the ledger snapshot hash, the agreement hash and the PayPal order ID. This is the evidence trail a dispute team would want when "no human pressed pay".

## Architecture

```
app/
  page.tsx                  two phones + the agent channel
  components/               Phone (chat, ledger, rules, approval), Channel (receipt tape)
  api/
    expenses                text or receipt photo -> ledger lines (Claude)
    negotiate               run the agent-to-agent protocol
    approve                 human approves or declines
    paypal/connect|return   Vault setup token -> PayPal approval -> payment token
    webhooks/paypal         verified PayPal events
    policy, state, reset
lib/
  agents.ts                 protocol: handshake, statement, dispute, ruling, agreement, guardrails, settle, confirm
  ledger.ts                 deterministic money math
  paypal.ts                 Vault, Orders, Payouts, webhook verification (+ demo mode)
  toolkit.ts                PayPal Agent Toolkit bridge to Claude tools
  ai.ts                     Claude client, JSON + tool-use loop
  trust.ts                  trust cards, message signatures, receipts
scripts/e2e.ts              end-to-end test of the whole flow
```

State lives in `data/db.json` (a single file, fine for a demo; swap for a database in production). On the hosted demo everyone shares one trip, so press **Reset the trip** if someone else left it mid-way.

Money flow in sandbox: the debtor's allowance is charged to the app's sandbox **business** account, which then pays the friend with Payouts. Keep some sandbox balance on that business account (new sandbox business accounts start with a balance).

## Set up the PayPal sandbox

1. At [developer.paypal.com](https://developer.paypal.com), create a sandbox app. Under its features, make sure **Vault** and **Payouts** are enabled.
2. Under **Sandbox accounts**, note two personal accounts (one for Alex, one for Maya). You'll log in as Alex's account when you click **Connect PayPal**.
3. Copy `.env.example` to `.env` and fill in `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET`, `ALEX_SANDBOX_EMAIL`, `MAYA_SANDBOX_EMAIL`, and optionally `ANTHROPIC_API_KEY`.
4. Optional: add a webhook pointing at `https://<your-host>/api/webhooks/paypal` and put its ID in `PAYPAL_WEBHOOK_ID`.
5. `npm run dev`.

## Deploy

Step-by-step instructions for Render (including how to keep Alex's PayPal allowance connected for judges) are in [DEPLOY.md](DEPLOY.md).

## Tests

```bash
npm test
```

Runs the complete flow in demo mode: invoice fallback, the $253 to $241 negotiation, escalation over the limit, approval, PayPal settlement, independent verification, ledger closing, and an auto-settle under the limit.

## Built with

Next.js 15, TypeScript, Claude (Anthropic API), PayPal REST APIs (Vault v3, Orders v2, Payouts, Invoicing, Webhooks), PayPal Agent Toolkit.

## License

MIT, see [LICENSE](LICENSE).
