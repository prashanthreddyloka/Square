import type { DB, Statement, UserId } from "../../lib/types";

export type Balance = { label: string; amount: number; direction: "owe" | "owed" | "even"; counterparty?: UserId };

export type AppState = DB & {
  modes: { paypal: "live" | "demo"; ai: "claude" | "demo" };
  statement: Statement;
  balances: Record<UserId, Balance>;
};

export type ChatLine = { role: "me" | "agent" | "note"; text: string; image?: string };
