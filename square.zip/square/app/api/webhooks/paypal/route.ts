import { verifyWebhook } from "../../../../lib/paypal";
import { mutate, uid } from "../../../../lib/store";
import { json } from "../../../../lib/http";

// Subscribe this URL to PAYMENT.CAPTURE.COMPLETED, PAYMENT.PAYOUTSBATCH.SUCCESS,
// PAYMENT.PAYOUTS-ITEM.SUCCEEDED, INVOICING.INVOICE.PAID and VAULT.PAYMENT-TOKEN.CREATED.
export async function POST(req: Request) {
  const event = await req.json().catch(() => null);
  if (!event?.event_type) return json({ ok: false }, 400);
  let verified = false;
  try {
    verified = await verifyWebhook(req.headers, event);
  } catch {
    verified = false;
  }
  if (process.env.PAYPAL_WEBHOOK_ID && !verified) return json({ ok: false, error: "signature" }, 401);
  mutate((db) => {
    db.webhookEvents.unshift({
      id: event.id || uid("evt"),
      type: event.event_type,
      receivedAt: new Date().toISOString(),
      summary: event.summary || event.resource?.status || "",
    });
    db.webhookEvents = db.webhookEvents.slice(0, 30);
  });
  return json({ ok: true });
}
