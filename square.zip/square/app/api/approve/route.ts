import { decide } from "../../../lib/agents";
import { fail, json } from "../../../lib/http";

export const maxDuration = 120;

export async function POST(req: Request) {
  try {
    const { negotiationId, decision } = await req.json();
    if (decision !== "approved" && decision !== "declined") return fail("Decision must be approved or declined.");
    return json(await decide(String(negotiationId), decision));
  } catch (e) {
    return fail(e);
  }
}
