import { negotiate } from "../../../lib/agents";
import { getDB } from "../../../lib/store";
import { fail, json } from "../../../lib/http";

export const maxDuration = 120;

export async function POST() {
  try {
    if (getDB().negotiations.some((n) => n.status === "awaiting_approval")) {
      return fail("A settle-up is already waiting for approval.");
    }
    return json(await negotiate());
  } catch (e) {
    return fail(e, 500);
  }
}
