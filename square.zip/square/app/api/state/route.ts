import { getDB } from "../../../lib/store";
import { balanceFor, buildStatement } from "../../../lib/ledger";
import { paypalMode } from "../../../lib/paypal";
import { aiMode } from "../../../lib/ai";
import { json } from "../../../lib/http";

export const dynamic = "force-dynamic";

export async function GET() {
  const db = getDB();
  const open = db.expenses.filter((e) => !e.settledIn);
  return json({
    ...db,
    modes: { paypal: paypalMode(), ai: aiMode() },
    statement: buildStatement(open),
    balances: { alex: balanceFor(db.expenses, "alex"), maya: balanceFor(db.expenses, "maya") },
  });
}
