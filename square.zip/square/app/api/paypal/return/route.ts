import { NextResponse } from "next/server";
import { createPaymentToken, paypalMode } from "../../../../lib/paypal";
import { getDB, mutate } from "../../../../lib/store";
import { baseUrl, isUser } from "../../../../lib/http";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const user = url.searchParams.get("user");
  const base = baseUrl(req);
  if (!isUser(user)) return NextResponse.redirect(`${base}/?linked=error`);
  const db = getDB();
  const setupTokenId = url.searchParams.get("approval_token_id") || db.users[user].paypal.setupTokenId;
  try {
    if (!setupTokenId) throw new Error("Missing setup token");
    const t = await createPaymentToken(setupTokenId, db.users[user].sandboxEmail);
    mutate((d) => {
      d.users[user].paypal = {
        status: "linked",
        setupTokenId,
        paymentTokenId: t.id,
        customerId: t.customerId,
        payerId: t.payerId,
        payerEmail: t.email,
        linkedAt: new Date().toISOString(),
        mode: paypalMode(),
      };
    });
    return NextResponse.redirect(`${base}/?linked=${user}`);
  } catch (e) {
    mutate((d) => {
      d.users[user].paypal = { status: "unlinked" };
    });
    return NextResponse.redirect(`${base}/?linked=error&reason=${encodeURIComponent((e as Error).message.slice(0, 160))}`);
  }
}
