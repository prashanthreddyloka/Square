import crypto from "node:crypto";
import type { AgentMessage, User, UserId } from "./types";

const ROOT = process.env.SQUARE_SIGNING_SECRET || "square-dev-signing-secret-change-me";

// Each agent gets its own passport key, derived from the server root key.
function agentKey(agent: UserId | "square") {
  return crypto.createHmac("sha256", ROOT).update(`agent:${agent}`).digest();
}

export function sha256(v: unknown) {
  return crypto.createHash("sha256").update(typeof v === "string" ? v : JSON.stringify(v)).digest("hex");
}

export function sign(agent: UserId | "square", payload: unknown) {
  return crypto.createHmac("sha256", agentKey(agent)).update(JSON.stringify(payload)).digest("hex");
}

export function verify(agent: UserId | "square", payload: unknown, sig: string) {
  const expected = sign(agent, payload);
  return expected.length === sig.length && crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(sig));
}

export function signMessage(m: Omit<AgentMessage, "sig">): AgentMessage {
  return { ...m, sig: sign(m.from, { type: m.type, text: m.text, data: m.data ?? null, ts: m.ts }) };
}

export function verifyMessage(m: AgentMessage) {
  if (!m.sig) return false;
  return verify(m.from, { type: m.type, text: m.text, data: m.data ?? null, ts: m.ts }, m.sig);
}

/**
 * A trust card is what one agent shows another before money moves.
 * It binds the agent to a PayPal-verified human (from the vaulted payment token)
 * and to a hash of that human's current rules, so the counterparty knows the
 * agent is acting under a real mandate.
 */
export interface TrustCard {
  agent: string;
  human: string;
  paypalVerified: boolean;
  payerId: string | null;
  canPay: boolean; // has a vaulted PayPal allowance
  policyHash: string;
  issuedAt: string;
  sig: string;
}

export function issueTrustCard(user: User): TrustCard {
  const body = {
    agent: `square-agent:${user.id}`,
    human: user.name,
    paypalVerified: user.paypal.status === "linked",
    payerId: user.paypal.payerId ?? null,
    canPay: Boolean(user.paypal.paymentTokenId),
    policyHash: sha256(user.policy).slice(0, 16),
    issuedAt: new Date().toISOString(),
  };
  return { ...body, sig: sign("square", body) };
}

export function checkTrustCard(card: TrustCard) {
  const { sig, ...body } = card;
  return verify("square", body, sig);
}
