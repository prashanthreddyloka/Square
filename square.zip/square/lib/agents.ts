import { aiMode, ask, askJSON, askWithTools, imageBlock } from "./ai";
import { buildStatement, money, other, round2 } from "./ledger";
import { chargeAllowance, payFriend, paypalMode } from "./paypal";
import { getDB, mutate, uid } from "./store";
import { claudeTools, runTool, sendFriendInvoice } from "./toolkit";
import { checkTrustCard, issueTrustCard, sha256, sign, signMessage } from "./trust";
import type { AgentMessage, Dispute, Expense, LineItem, MessageType, Negotiation, Statement, User, UserId } from "./types";

const now = () => new Date().toISOString();

function msg(from: UserId | "square", type: MessageType, text: string, data?: Record<string, unknown>): AgentMessage {
  return signMessage({ id: uid("m"), from, type, text, data, ts: now() });
}

function persona(u: User, counterparty: User) {
  return [
    `You are ${u.name}'s personal agent inside Square, an app where friends' AI agents settle shared expenses on PayPal.`,
    `You represent ${u.name} only. You are talking to ${counterparty.name}'s agent, not to ${counterparty.name}.`,
    `${u.name}'s instructions: ${u.policy.instructions}`,
    `What you know about ${u.name}: ${u.policy.memory.join(" ") || "nothing yet."}`,
    `Square computes every amount. Never invent or recalculate money; only refer to amounts you are given.`,
    `Write like a friendly, concise person texting: one to three short sentences, no lists, no emoji.`,
  ].join("\n");
}

/* ------------------------------------------------------------------ */
/* Expense capture: chat text or a receipt photo becomes ledger lines  */
/* ------------------------------------------------------------------ */

type ParsedExpense = {
  description: string;
  paidBy: UserId;
  items: { label: string; amount: number; kind: "consumable" | "shared-fixed"; sharedBy: UserId[] }[];
  reply: string;
};

export async function captureExpense(author: UserId, text: string, image?: string): Promise<{ expense: Expense; reply: string }> {
  const db = getDB();
  const me = db.users[author];
  const friend = db.users[other(author)];
  let parsed: ParsedExpense;

  if (aiMode() === "claude") {
    const system = [
      `You turn a message from ${me.name} (and optionally a receipt photo) into a shared expense between ${me.name} (id "${me.id}") and ${friend.name} (id "${friend.id}").`,
      `Return {"description": string, "paidBy": "alex"|"maya", "items": [{"label": string, "amount": number, "kind": "consumable"|"shared-fixed", "sharedBy": ["alex"|"maya", ...]}], "reply": string}.`,
      `Itemize receipts line by line when you can read them, so items can later be disputed individually. Use "consumable" for food, drinks and personal goods, "shared-fixed" for rent, tickets, rides and bookings.`,
      `Default sharedBy to both people unless the message says otherwise. Assume ${me.name} paid unless the message says ${friend.name} paid.`,
      `Amounts are in USD and must add up to the receipt total. "reply" is a one-sentence confirmation to ${me.name}.`,
    ].join("\n");
    const content = image
      ? [imageBlock(image), { type: "text" as const, text: text || "Here's the receipt." }]
      : text;
    parsed = await askJSON<ParsedExpense>(system, content);
  } else {
    if (image) throw new Error("Reading receipt photos needs Claude. Add ANTHROPIC_API_KEY, or type the amount instead.");
    parsed = ruleBasedParse(author, friend.id, text);
  }

  const items: LineItem[] = (parsed.items || [])
    .filter((i) => Number(i.amount) > 0)
    .map((i) => ({
      id: uid("i"),
      label: String(i.label).slice(0, 80),
      amount: round2(Number(i.amount)),
      kind: i.kind === "shared-fixed" ? "shared-fixed" : "consumable",
      sharedBy: (i.sharedBy?.length ? i.sharedBy : ["alex", "maya"]).filter((u): u is UserId => u === "alex" || u === "maya"),
    }));
  if (items.length === 0) throw new Error("I couldn't find an amount in that. Try something like “I paid $42 for groceries”.");

  const expense: Expense = {
    id: uid("exp"),
    description: String(parsed.description || items[0].label).slice(0, 80),
    paidBy: parsed.paidBy === "alex" || parsed.paidBy === "maya" ? parsed.paidBy : author,
    date: now().slice(0, 10),
    source: image ? "receipt" : "chat",
    items,
  };
  mutate((d) => d.expenses.push(expense));
  return { expense, reply: parsed.reply || `Added ${expense.description} for ${money(items.reduce((s, i) => s + i.amount, 0))}, split with ${friend.name}.` };
}

function ruleBasedParse(author: UserId, friend: UserId, text: string): ParsedExpense {
  const amounts = [...text.matchAll(/\$?\s?(\d+(?:\.\d{1,2})?)/g)].map((m) => Number(m[1]));
  const amount = amounts[0] ?? 0;
  const lower = text.toLowerCase();
  const friendName = friend === "alex" ? "alex" : "maya";
  const paidBy: UserId = new RegExp(`${friendName} paid`).test(lower) ? friend : author;
  const forMatch = /for (.+?)(?:[,.]|$)/i.exec(text);
  const label = forMatch ? forMatch[1].trim() : "Shared expense";
  const fixed = /(rent|airbnb|hotel|ticket|uber|taxi|ride|flight|train|parking)/i.test(text);
  return {
    description: label.charAt(0).toUpperCase() + label.slice(1),
    paidBy,
    items: [{ label: label.charAt(0).toUpperCase() + label.slice(1), amount, kind: fixed ? "shared-fixed" : "consumable", sharedBy: ["alex", "maya"] }],
    reply: `Got it: ${label} for ${money(amount)}, split evenly.`,
  };
}

/* ------------------------------------------------------------------ */
/* Agent-to-agent negotiation                                          */
/* ------------------------------------------------------------------ */

type Review = { disputes: { itemId: string; reason: string }[]; message: string };
type Ruling = { rulings: { itemId: string; accept: boolean; reason: string }[]; message: string };

function statementText(s: Statement, db = getDB()) {
  return s.lines
    .map((l) => `- [${l.itemId}] ${l.label} (${l.expense}, paid by ${db.users[l.paidBy].name}): ${l.signed >= 0 ? "" : "credit "}${money(Math.abs(l.signed))}`)
    .join("\n");
}

async function debtorReview(debtor: User, creditor: User, s: Statement): Promise<Review> {
  const db = getDB();
  const owedLines = s.lines.filter((l) => l.signed > 0);
  if (aiMode() === "claude") {
    const items = owedLines.map((l) => {
      const exp = db.expenses.find((e) => e.id === l.expenseId)!;
      const it = exp.items.find((i) => i.id === l.itemId)!;
      return `- itemId "${l.itemId}": ${l.label} (${l.expense}), kind ${it.kind}, ${debtor.name}'s share ${money(l.share)}`;
    });
    return askJSON<Review>(
      persona(debtor, creditor),
      [
        `${creditor.name}'s agent sent this statement. ${debtor.name} owes ${money(s.total)} net.`,
        `Lines ${debtor.name} is being charged for:\n${items.join("\n")}`,
        `Dispute only lines that conflict with what you know about ${debtor.name} or their instructions. Do not dispute lines just to save money.`,
        `Return {"disputes":[{"itemId": string, "reason": string}], "message": string}. "message" is what you say to ${creditor.name}'s agent.`,
      ].join("\n\n"),
    );
  }
  // Rule-based reviewer: match what the agent knows about its human against line items.
  const memory = debtor.policy.memory.join(" ").toLowerCase();
  const disputes: Review["disputes"] = [];
  for (const l of owedLines) {
    const label = `${l.label} ${l.expense}`.toLowerCase();
    if (/(wine|vinho|beer|cocktail|sangria|bar|drinks?)/.test(label) && /(doesn't|does not|don't) drink/.test(memory)) {
      disputes.push({ itemId: l.itemId, reason: `${debtor.name} doesn't drink, so the ${l.label.toLowerCase()} shouldn't be split with them.` });
    }
    if (/(fado|show|concert|ticket)/.test(label) && /(left|leave).*(early|intermission)/.test(memory)) {
      disputes.push({ itemId: l.itemId, reason: `${debtor.name} left the show at intermission, so they'd rather not pay a full share.` });
    }
  }
  return {
    disputes,
    message: disputes.length
      ? `Thanks for pulling this together. Before ${debtor.name} pays, I'd like to raise ${disputes.length === 1 ? "one line" : `${disputes.length} lines`}.`
      : `Everything checks out on ${debtor.name}'s side.`,
  };
}

async function creditorRuling(creditor: User, debtor: User, disputes: Dispute[]): Promise<Ruling> {
  const db = getDB();
  if (aiMode() === "claude") {
    const lines = disputes.map((d) => {
      const it = db.expenses.find((e) => e.id === d.expenseId)!.items.find((i) => i.id === d.itemId)!;
      return `- itemId "${d.itemId}": ${d.itemLabel}, kind ${it.kind}. Their reason: ${d.reason}`;
    });
    return askJSON<Ruling>(
      persona(creditor, debtor),
      [
        `${debtor.name}'s agent disputes these lines:\n${lines.join("\n")}`,
        `Decide each one by following ${creditor.name}'s instructions exactly. Be fair, not stubborn.`,
        `Return {"rulings":[{"itemId": string, "accept": boolean, "reason": string}], "message": string}.`,
      ].join("\n\n"),
    );
  }
  const rulings = disputes.map((d) => {
    const it = db.expenses.find((e) => e.id === d.expenseId)!.items.find((i) => i.id === d.itemId)!;
    return it.kind === "consumable"
      ? { itemId: d.itemId, accept: true, reason: `Fair enough, ${debtor.name} didn't have it.` }
      : { itemId: d.itemId, accept: false, reason: `That was booked for both of you, so it stays split even though ${debtor.name} left early.` };
  });
  const accepted = rulings.filter((r) => r.accept).length;
  return {
    rulings,
    message:
      accepted === rulings.length
        ? "All fair, I've taken those off."
        : accepted === 0
          ? `I hear you, but ${creditor.name}'s rule is that shared bookings stay shared.`
          : `I'll take one off, but ${creditor.name}'s rule is that shared bookings stay shared.`,
  };
}

async function say(u: User, counterparty: User, prompt: string, fallback: string) {
  if (aiMode() !== "claude") return fallback;
  try {
    return (await ask(persona(u, counterparty), prompt, 200)) || fallback;
  } catch {
    return fallback;
  }
}

function sentThisWeek(user: UserId) {
  const weekAgo = Date.now() - 7 * 864e5;
  return getDB()
    .negotiations.filter((n) => n.debtor === user && n.status === "settled" && n.settlement && Date.parse(n.settlement.settledAt) > weekAgo)
    .reduce((s, n) => s + n.agreedAmount, 0);
}

export async function negotiate(): Promise<Negotiation> {
  const db = getDB();
  const open = db.expenses.filter((e) => !e.settledIn);
  const s0 = buildStatement(open);
  const debtor = db.users[s0.debtor];
  const creditor = db.users[s0.creditor];
  const n: Negotiation = {
    id: uid("neg"),
    status: "agreed",
    debtor: debtor.id,
    creditor: creditor.id,
    startedAt: now(),
    messages: [],
    disputes: [],
    initialTotal: s0.total,
    agreedAmount: s0.total,
    aiMode: aiMode(),
  };
  const push = (m: AgentMessage) => n.messages.push(m);

  try {
    if (s0.total === 0) {
      n.status = "nothing_owed";
      push(msg("square", "AGREE", "Nothing to settle. You two are all square."));
      return save(n);
    }

    // 1. Handshake: each agent presents a PayPal-backed trust card, and each checks the other's.
    const cCard = issueTrustCard(creditor);
    const dCard = issueTrustCard(debtor);
    push(msg(creditor.id, "HELLO", `Hi, I'm ${creditor.name}'s agent. Here's my trust card.`, { trustCard: cCard }));
    push(msg(debtor.id, "HELLO", `Hey, ${debtor.name}'s agent here. Here's mine.`, { trustCard: dCard }));
    const checks = {
      creditorCardValid: checkTrustCard(cCard),
      debtorCardValid: checkTrustCard(dCard),
      creditorPayPalVerified: cCard.paypalVerified,
      debtorPayPalVerified: dCard.paypalVerified,
      debtorCanPay: dCard.canPay,
    };
    push(
      msg(
        "square",
        "VERIFY",
        [
          checks.creditorCardValid && checks.debtorCardValid ? "Both trust cards are authentic." : "A trust card failed verification.",
          checks.debtorPayPalVerified
            ? `${debtor.name} is a verified PayPal user with an approved agent allowance.`
            : `${debtor.name} hasn't connected PayPal yet, so ${debtor.name}'s agent can negotiate but can't pay. If you agree, ${creditor.name}'s agent will send a PayPal invoice instead.`,
          checks.creditorPayPalVerified ? `${creditor.name} is a verified PayPal user.` : `${creditor.name} will be paid at ${creditor.sandboxEmail}.`,
        ].join(" "),
        checks,
      ),
    );
    if (!checks.creditorCardValid || !checks.debtorCardValid) {
      n.status = "failed";
      return save(n);
    }

    // 2. Proposal: creditor's agent sends the itemized statement Square computed.
    const proposeText = await say(
      creditor,
      debtor,
      `Open the settle-up with ${debtor.name}'s agent. Net, ${debtor.name} owes ${money(s0.total)} across ${s0.lines.length} lines from the shared trip. Mention the total and invite them to check the lines.`,
      `Across your shared expenses, ${debtor.name} owes ${creditor.name} ${money(s0.total)} net. Itemized lines attached, take a look.`,
    );
    push(msg(creditor.id, "PROPOSE", proposeText, { total: s0.total, lines: s0.lines, ledgerHash: sha256(open).slice(0, 16) }));

    // 3. Review: debtor's agent checks each line against what it knows about its human.
    const review = await debtorReview(debtor, creditor, s0);
    const valid = review.disputes
      .map((d) => {
        const line = s0.lines.find((l) => l.itemId === d.itemId && l.signed > 0);
        if (!line) return null;
        return { expenseId: line.expenseId, itemId: line.itemId, itemLabel: line.label, reason: d.reason, remove: debtor.id } as Dispute;
      })
      .filter((d): d is Dispute => Boolean(d));
    n.disputes = valid;

    if (valid.length) {
      push(msg(debtor.id, "DISPUTE", review.message, { disputes: valid.map(({ itemId, itemLabel, reason }) => ({ itemId, itemLabel, reason })) }));

      // 4. Ruling: creditor's agent decides each dispute under its human's rules.
      const ruling = await creditorRuling(creditor, debtor, valid);
      for (const d of n.disputes) {
        const r = ruling.rulings.find((x) => x.itemId === d.itemId);
        d.accepted = Boolean(r?.accept);
        d.ruling = r?.reason || (d.accepted ? "Accepted." : "Declined.");
      }
      push(msg(creditor.id, "RULING", ruling.message, { rulings: n.disputes.map(({ itemId, itemLabel, accepted, ruling: why }) => ({ itemId, itemLabel, accepted, why })) }));
    }

    // 5. Agreement on a number Square recomputes from the accepted adjustments.
    const s1 = buildStatement(open, n.disputes);
    n.agreedAmount = s1.total;
    const changed = round2(s0.total - s1.total);
    const agreeText = await say(
      debtor,
      creditor,
      `Agree to settle. The final amount is ${money(s1.total)}${changed ? ` (down ${money(changed)} from the opening ${money(s0.total)})` : ""}. ${
        n.disputes.some((d) => !d.accepted) ? "Accept the declined dispute gracefully." : ""
      }`,
      `Deal. ${money(s1.total)} it is${changed ? `, thanks for taking ${money(changed)} off` : ""}.`,
    );
    push(msg(debtor.id, "AGREE", agreeText, { amount: s1.total, agreementHash: sha256({ lines: s1.lines, total: s1.total }).slice(0, 16) }));

    // 6. Guardrails: deterministic rules, not the model, decide whether money can move.
    if (!debtor.paypal.paymentTokenId) {
      return save(await invoiceInstead(n, debtor, creditor, s1));
    }
    const weekTotal = sentThisWeek(debtor.id);
    if (weekTotal + s1.total > debtor.policy.weeklyCap) {
      n.status = "awaiting_approval";
      n.approval = { userId: debtor.id, reason: `This would take ${debtor.name} past their ${money(debtor.policy.weeklyCap)} weekly cap (${money(weekTotal)} already sent this week).` };
      push(msg(debtor.id, "ESCALATE", `This is over ${debtor.name}'s weekly cap, so I'm checking with ${debtor.name} first.`, { amount: s1.total, rule: "weeklyCap" }));
      return save(n);
    }
    if (s1.total > debtor.policy.autoApproveMax) {
      n.status = "awaiting_approval";
      n.approval = { userId: debtor.id, reason: `${money(s1.total)} is above ${debtor.name}'s auto-approve limit of ${money(debtor.policy.autoApproveMax)}.` };
      push(
        msg(
          debtor.id,
          "ESCALATE",
          `That's above the ${money(debtor.policy.autoApproveMax)} I can send on my own, so I've asked ${debtor.name} to approve it. One tap on their phone.`,
          { amount: s1.total, rule: "autoApproveMax" },
        ),
      );
      return save(n);
    }
    save(n);
    return await settle(n.id, "auto");
  } catch (e) {
    n.status = "failed";
    push(msg("square", "ERROR", `Something went wrong: ${(e as Error).message}`));
    return save(n);
  }
}

function save(n: Negotiation): Negotiation {
  mutate((db) => {
    const i = db.negotiations.findIndex((x) => x.id === n.id);
    if (i >= 0) db.negotiations[i] = n;
    else db.negotiations.unshift(n);
  });
  return n;
}

async function invoiceInstead(n: Negotiation, debtor: User, creditor: User, s: Statement) {
  const db = getDB();
  const lines = s.lines
    .filter((l) => l.signed > 0)
    .map((l) => ({ name: l.label, description: `${l.expense}, your share`, amount: l.share }));
  const credits = s.lines.filter((l) => l.signed < 0);
  if (credits.length) {
    lines.push({
      name: "Already covered by you",
      description: credits.map((c) => c.label).join(", "),
      amount: -round2(credits.reduce((sum, c) => sum + Math.abs(c.signed), 0)),
    });
  }
  const inv = await sendFriendInvoice({
    fromName: creditor.name,
    fromEmail: creditor.sandboxEmail,
    toName: debtor.name,
    toEmail: db.users[debtor.id].sandboxEmail,
    lines,
    note: `Itemized and agreed by your Square agents. Total ${money(s.total)}.`,
  });
  n.status = "invoiced";
  // The invoice now carries the balance, so close these lines to avoid billing twice.
  mutate((d) => {
    for (const e of d.expenses) if (!e.settledIn) e.settledIn = n.id;
  });
  n.messages.push(
    msg(
      creditor.id,
      "INVOICE",
      `${debtor.name} hasn't connected an allowance yet, so I've sent ${debtor.name} an itemized PayPal invoice for ${money(s.total)} instead.`,
      { invoiceId: inv.id, url: inv.url, viaAgentToolkit: true },
    ),
  );
  return n;
}

/* ------------------------------------------------------------------ */
/* Human approval and settlement on PayPal                             */
/* ------------------------------------------------------------------ */

export async function decide(negotiationId: string, decision: "approved" | "declined") {
  const n = getDB().negotiations.find((x) => x.id === negotiationId);
  if (!n || n.status !== "awaiting_approval" || !n.approval) throw new Error("There's nothing waiting for approval.");
  const db = getDB();
  const human = db.users[n.approval.userId];
  n.approval.decision = decision;
  n.approval.decidedAt = now();
  if (decision === "declined") {
    n.status = "declined";
    n.messages.push(msg(human.id, "DECLINED", `${human.name} declined for now. Nothing was sent.`));
    return save(n);
  }
  n.messages.push(msg(human.id, "APPROVED", `${human.name} approved ${money(n.agreedAmount)}. Sending it now.`, { approvedBy: human.id }));
  save(n);
  return settle(n.id, "human");
}

export async function settle(negotiationId: string, via: "auto" | "human"): Promise<Negotiation> {
  const db = getDB();
  const n = db.negotiations.find((x) => x.id === negotiationId)!;
  const debtor = db.users[n.debtor];
  const creditor = db.users[n.creditor];
  const reference = n.id.replace(/[^A-Za-z0-9_-]/g, "").slice(0, 30);
  try {
    const order = await chargeAllowance({
      vaultId: debtor.paypal.paymentTokenId!,
      amount: n.agreedAmount,
      description: `Square: ${debtor.name} settling up with ${creditor.name}`,
      reference,
    });
    const payout = await payFriend({
      email: creditor.paypal.payerEmail || creditor.sandboxEmail,
      amount: n.agreedAmount,
      note: `${debtor.name}'s agent settled up with you on Square. ${n.disputes.length ? `Adjusted: ${n.disputes.map((d) => `${d.itemLabel} (${d.accepted ? "removed" : "kept"})`).join(", ")}.` : ""}`,
      reference,
    });
    n.messages.push(
      msg(debtor.id, "SETTLE", `Sent ${money(n.agreedAmount)} via PayPal.`, {
        orderId: order.orderId,
        captureId: order.captureId,
        payoutBatchId: payout.batchId,
        payoutStatus: payout.status,
        via,
      }),
    );

    // The creditor's agent doesn't take the other agent's word for it: it checks PayPal itself.
    const confirmation = await confirmOnPayPal(creditor, debtor, order.orderId, n.agreedAmount);
    n.messages.push(msg(creditor.id, "CONFIRM", confirmation.text, { verified: confirmation.verified, toolCalls: confirmation.calls }));

    const ledgerHash = sha256(db.expenses.filter((e) => !e.settledIn)).slice(0, 16);
    const agreementHash = sha256({ id: n.id, amount: n.agreedAmount, disputes: n.disputes }).slice(0, 16);
    const receiptBody = { id: uid("rcpt"), ledgerHash, agreementHash, paymentRef: order.orderId, issuedAt: now() };
    n.settlement = {
      mode: paypalMode(),
      orderId: order.orderId,
      orderStatus: order.status,
      captureId: order.captureId,
      payoutBatchId: payout.batchId,
      payoutItemId: payout.itemId,
      payoutStatus: payout.status,
      amount: n.agreedAmount,
      currency: "USD",
      settledAt: now(),
      receipt: { ...receiptBody, sig: sign("square", receiptBody) },
    };
    n.status = "settled";

    // Close the ledger and make accepted adjustments permanent.
    mutate((d) => {
      for (const e of d.expenses) {
        if (e.settledIn) continue;
        for (const it of e.items) {
          const disp = n.disputes.find((x) => x.itemId === it.id && x.accepted);
          if (disp) it.sharedBy = it.sharedBy.filter((u) => u !== disp.remove);
        }
        e.settledIn = n.id;
      }
    });
    return save(n);
  } catch (e) {
    n.status = "failed";
    n.messages.push(msg("square", "ERROR", `PayPal settlement failed: ${(e as Error).message}`));
    return save(n);
  }
}

async function confirmOnPayPal(creditor: User, debtor: User, orderId: string, amount: number) {
  if (aiMode() === "claude") {
    try {
      const r = await askWithTools(
        `${persona(creditor, debtor)}\nYou can call PayPal Agent Toolkit tools. Verify payments yourself; never trust the other agent's claim.`,
        `${debtor.name}'s agent says it paid ${money(amount)} in PayPal order ${orderId}. Check the order on PayPal. Then reply with JSON {"verified": boolean, "message": string} where message is your one-sentence confirmation to ${debtor.name}'s agent.`,
        claudeTools(["get_order"]),
        runTool,
      );
      const j = JSON.parse(r.text.slice(r.text.indexOf("{"), r.text.lastIndexOf("}") + 1));
      return { verified: Boolean(j.verified), text: String(j.message), calls: r.calls };
    } catch {
      // fall through to direct verification
    }
  }
  const raw = JSON.parse(await runTool("get_order", { id: orderId }));
  const verified = raw.status === "COMPLETED";
  return {
    verified,
    text: verified
      ? `Checked PayPal myself: order ${orderId} is completed. Thanks, we're square.`
      : `PayPal shows order ${orderId} as ${raw.status}, so I'm not marking this settled yet.`,
    calls: [{ name: "get_order", input: { id: orderId } }],
  };
}
