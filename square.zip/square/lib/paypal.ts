/**
 * PayPal sandbox integration.
 *
 * Live mode (PAYPAL_CLIENT_ID + PAYPAL_CLIENT_SECRET set):
 *   - Vault v3 setup tokens + payment tokens: each human approves their agent's allowance once
 *   - Orders v2 with a vault_id: the debtor's agent pays without the human present
 *   - Payouts v1: Square forwards the money to the friend's PayPal account
 *   - Invoicing v2 (via PayPal Agent Toolkit): fallback when the friend has no agent yet
 *   - Webhooks: payout and capture events land in the activity feed
 *
 * Demo mode (no credentials): the same flow with simulated PayPal responses,
 * clearly labelled in the UI, so the project always runs for judges.
 */
import { uid } from "./store";

const BASE = process.env.PAYPAL_ENV === "live" ? "https://api-m.paypal.com" : "https://api-m.sandbox.paypal.com";

export const paypalMode = (): "live" | "demo" =>
  process.env.PAYPAL_CLIENT_ID && process.env.PAYPAL_CLIENT_SECRET ? "live" : "demo";

let cached: { token: string; exp: number } | null = null;

export async function accessToken() {
  if (cached && cached.exp > Date.now() + 60_000) return cached.token;
  const auth = Buffer.from(`${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`).toString("base64");
  const res = await fetch(`${BASE}/v1/oauth2/token`, {
    method: "POST",
    headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/x-www-form-urlencoded" },
    body: "grant_type=client_credentials",
  });
  if (!res.ok) throw new Error(`PayPal auth failed (${res.status}): ${await res.text()}`);
  const j = (await res.json()) as { access_token: string; expires_in: number };
  cached = { token: j.access_token, exp: Date.now() + j.expires_in * 1000 };
  return j.access_token;
}

async function pp<T>(method: string, path: string, body?: unknown, extraHeaders: Record<string, string> = {}): Promise<T> {
  const token = await accessToken();
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      Prefer: "return=representation",
      "PayPal-Request-Id": uid("sq"),
      ...extraHeaders,
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  if (!res.ok) {
    let detail = text;
    try {
      const j = JSON.parse(text);
      detail = j.details?.[0]?.description || j.message || j.error_description || text;
    } catch {}
    throw new Error(`PayPal ${method} ${path} failed (${res.status}): ${detail}`);
  }
  return (text ? JSON.parse(text) : {}) as T;
}

/* ---------- Vault: one-time approval of an agent allowance ---------- */

export async function createSetupToken(opts: { returnUrl: string; cancelUrl: string; human: string }) {
  if (paypalMode() === "demo") {
    const id = uid("DEMO-SETUP");
    return { id, approveUrl: `${opts.returnUrl}${opts.returnUrl.includes("?") ? "&" : "?"}approval_token_id=${id}&demo=1` };
  }
  const r = await pp<{ id: string; links: { rel: string; href: string }[] }>("POST", "/v3/vault/setup-tokens", {
    payment_source: {
      paypal: {
        description: `Square agent allowance for ${opts.human}: lets your Square agent settle shared expenses with friends within the limits you set.`,
        usage_pattern: "IMMEDIATE",
        usage_type: "MERCHANT",
        customer_type: "CONSUMER",
        permit_multiple_payment_tokens: false,
        experience_context: {
          brand_name: "Square",
          locale: "en-US",
          shipping_preference: "NO_SHIPPING",
          return_url: opts.returnUrl,
          cancel_url: opts.cancelUrl,
        },
      },
    },
  });
  const approveUrl = r.links.find((l) => l.rel === "approve")?.href;
  if (!approveUrl) throw new Error("PayPal did not return an approval link for the setup token.");
  return { id: r.id, approveUrl };
}

export async function createPaymentToken(setupTokenId: string, fallbackEmail: string) {
  if (paypalMode() === "demo") {
    return {
      id: uid("DEMO-PMTTOKEN"),
      customerId: uid("DEMO-CUST"),
      payerId: uid("DEMOPAYER").toUpperCase(),
      email: fallbackEmail,
    };
  }
  const r = await pp<{
    id: string;
    customer?: { id: string };
    payment_source?: { paypal?: { email_address?: string; payer_id?: string } };
  }>("POST", "/v3/vault/payment-tokens", { payment_source: { token: { id: setupTokenId, type: "SETUP_TOKEN" } } });
  return {
    id: r.id,
    customerId: r.customer?.id ?? "",
    payerId: r.payment_source?.paypal?.payer_id ?? "",
    email: r.payment_source?.paypal?.email_address ?? fallbackEmail,
  };
}

/* ---------- Settlement: charge the debtor's allowance, pay the friend ---------- */

export async function chargeAllowance(opts: { vaultId: string; amount: number; description: string; reference: string }) {
  if (paypalMode() === "demo") {
    return { orderId: uid("DEMO-ORDER").toUpperCase(), status: "COMPLETED", captureId: uid("DEMO-CAPTURE").toUpperCase() };
  }
  type Order = {
    id: string;
    status: string;
    purchase_units?: { payments?: { captures?: { id: string; status: string }[] } }[];
  };
  let order = await pp<Order>("POST", "/v2/checkout/orders", {
    intent: "CAPTURE",
    payment_source: { paypal: { vault_id: opts.vaultId } },
    purchase_units: [
      {
        reference_id: opts.reference,
        custom_id: opts.reference,
        description: opts.description.slice(0, 127),
        amount: { currency_code: "USD", value: opts.amount.toFixed(2) },
      },
    ],
  });
  if (order.status === "APPROVED" || order.status === "CREATED") {
    order = await pp<Order>("POST", `/v2/checkout/orders/${order.id}/capture`, {});
  }
  const capture = order.purchase_units?.[0]?.payments?.captures?.[0];
  if (order.status !== "COMPLETED") throw new Error(`Order ${order.id} ended in status ${order.status}`);
  return { orderId: order.id, status: order.status, captureId: capture?.id };
}

export async function payFriend(opts: { email: string; amount: number; note: string; reference: string }) {
  if (paypalMode() === "demo") {
    return { batchId: uid("DEMO-BATCH").toUpperCase(), itemId: uid("DEMO-ITEM").toUpperCase(), status: "SUCCESS" };
  }
  const r = await pp<{ batch_header: { payout_batch_id: string; batch_status: string } }>("POST", "/v1/payments/payouts", {
    sender_batch_header: {
      sender_batch_id: opts.reference,
      email_subject: "Your friend's Square agent settled up",
      email_message: opts.note.slice(0, 1000),
    },
    items: [
      {
        recipient_type: "EMAIL",
        receiver: opts.email,
        amount: { value: opts.amount.toFixed(2), currency: "USD" },
        note: opts.note.slice(0, 4000),
        sender_item_id: `${opts.reference}-1`,
      },
    ],
  });
  const batchId = r.batch_header.payout_batch_id;
  // Sandbox payouts usually resolve within a few seconds.
  let itemId: string | undefined;
  let status = r.batch_header.batch_status;
  for (let i = 0; i < 4; i++) {
    await new Promise((res) => setTimeout(res, 1500));
    const b = await getPayout(batchId);
    status = b.items?.[0]?.transaction_status || b.batch_header.batch_status;
    itemId = b.items?.[0]?.payout_item_id;
    if (status === "SUCCESS" || status === "UNCLAIMED" || status === "FAILED") break;
  }
  return { batchId, itemId, status };
}

export async function getPayout(batchId: string) {
  return pp<{
    batch_header: { batch_status: string };
    items?: { payout_item_id: string; transaction_status: string }[];
  }>("GET", `/v1/payments/payouts/${batchId}`);
}

export async function getOrder(orderId: string) {
  if (paypalMode() === "demo" || orderId.startsWith("DEMO")) {
    return { id: orderId, status: "COMPLETED" };
  }
  return pp<{ id: string; status: string }>("GET", `/v2/checkout/orders/${orderId}`);
}

/* ---------- Webhooks ---------- */

export async function verifyWebhook(headers: Headers, event: unknown) {
  const webhookId = process.env.PAYPAL_WEBHOOK_ID;
  if (!webhookId || paypalMode() === "demo") return false;
  const r = await pp<{ verification_status: string }>("POST", "/v1/notifications/verify-webhook-signature", {
    auth_algo: headers.get("paypal-auth-algo"),
    cert_url: headers.get("paypal-cert-url"),
    transmission_id: headers.get("paypal-transmission-id"),
    transmission_sig: headers.get("paypal-transmission-sig"),
    transmission_time: headers.get("paypal-transmission-time"),
    webhook_id: webhookId,
    webhook_event: event,
  });
  return r.verification_status === "SUCCESS";
}

export const sandboxLinks = {
  order: (id: string) => `https://www.sandbox.paypal.com/activity/payment/${id}`,
};
